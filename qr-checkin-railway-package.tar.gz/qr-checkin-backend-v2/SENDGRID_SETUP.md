# SendGrid Email Setup Instructions

## Step 1: Create SendGrid Account

1. Go to https://sendgrid.com
2. Click "Sign Up" and create a free account
3. Verify your email address
4. Complete the account setup process

## Step 2: Create API Key

1. Log in to your SendGrid dashboard
2. Navigate to **Settings** → **API Keys**
3. Click **Create API Key**
4. Name it (e.g., "QR Check-in System")
5. Select **Full Access** or at minimum **Mail Send** permissions
6. Click **Create & View**
7. **IMPORTANT**: Copy the API key immediately (you won't see it again!)

## Step 3: Verify Sender Identity

SendGrid requires sender verification to prevent spam:

1. Go to **Settings** → **Sender Authentication**
2. Choose one of these options:
   - **Single Sender Verification** (easiest for testing):
     - Click "Verify a Single Sender"
     - Fill in your email and business details
     - Verify the email they send you
   - **Domain Authentication** (better for production):
     - Follow the domain authentication process
     - Add DNS records to your domain

## Step 4: Configure the Application

Once you have your API key, you need to set it as an environment variable:

```bash
export SENDGRID_API_KEY="your_api_key_here"
export SENDGRID_FROM_EMAIL="your_verified_email@domain.com"
```

**Note**: The FROM_EMAIL must match the email you verified in Step 3.

## Step 5: Test the Integration

You can test the email integration using the test endpoint:

```bash
curl -X POST http://your-backend-url/api/email/test \
  -H "Content-Type: application/json" \
  -d '{"email": "your-test-email@example.com"}'
```

## Troubleshooting

### Email not sending?
- Make sure your API key is correct
- Verify that your sender email is verified in SendGrid
- Check SendGrid dashboard for error messages
- Look at the application logs for error details

### Emails going to spam?
- Complete domain authentication (not just single sender)
- Add SPF and DKIM records to your domain
- Warm up your sending reputation by starting with small volumes

### Free tier limits
- SendGrid free tier: 100 emails/day
- If you need more, consider upgrading to a paid plan

## Security Best Practices

1. **Never commit API keys to version control**
2. Use environment variables for sensitive data
3. Rotate API keys periodically
4. Use the minimum required permissions for API keys
5. Monitor your SendGrid dashboard for unusual activity

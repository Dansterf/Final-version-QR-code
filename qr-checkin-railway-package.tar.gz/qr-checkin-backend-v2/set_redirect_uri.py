#!/usr/bin/env python3
"""
Script to dynamically set QB_REDIRECT_URI based on current deployment URL
"""
import os
import sys

# Get the deployment URL from command line argument or environment
deployment_url = sys.argv[1] if len(sys.argv) > 1 else os.environ.get('DEPLOYMENT_URL', '')

if not deployment_url:
    print("Error: No deployment URL provided")
    sys.exit(1)

# Ensure URL doesn't have trailing slash
deployment_url = deployment_url.rstrip('/')

# Set the redirect URI
redirect_uri = f"{deployment_url}/api/quickbooks/callback"

print(f"Setting QB_REDIRECT_URI to: {redirect_uri}")

# Update main.py
with open('/home/ubuntu/qr-checkin-backend-v2/src/main.py', 'r') as f:
    content = f.read()

# Replace the hardcoded redirect URI
import re
pattern = r'os\.environ\["QB_REDIRECT_URI"\] = "https://[^"]+/api/quickbooks/callback"'
replacement = f'os.environ["QB_REDIRECT_URI"] = "{redirect_uri}"'
new_content = re.sub(pattern, replacement, content)

with open('/home/ubuntu/qr-checkin-backend-v2/src/main.py', 'w') as f:
    f.write(new_content)

print("Updated main.py successfully")


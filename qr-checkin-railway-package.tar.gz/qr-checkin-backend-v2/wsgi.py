#!/usr/bin/env python3
"""
WSGI entry point for the QR Check-In application.
This file sets environment variables before importing the Flask app.
"""
import os
import sys

# Set environment variables FIRST, before any application imports
os.environ["SENDGRID_API_KEY"] = "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"
os.environ["SENDGRID_FROM_EMAIL"] = "info@doulos.education"
os.environ["QR_CHECKIN_DB_PATH"] = "/home/ubuntu/qr-checkin-data"

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Now import the Flask application
from src.main import app

# WSGI servers will look for 'application'
application = app

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)

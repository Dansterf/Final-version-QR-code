#!/bin/bash
# Install SendGrid at runtime (after deployment)
pip3 install --user sendgrid python-http-client 2>/dev/null || echo "SendGrid installation skipped"

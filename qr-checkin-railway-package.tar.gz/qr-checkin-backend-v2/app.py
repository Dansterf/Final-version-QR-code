#!/usr/bin/env python3
import sys
import os

# Set environment variables FIRST, before any other imports
os.environ["SENDGRID_API_KEY"] = "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"
os.environ["SENDGRID_FROM_EMAIL"] = "info@doulos.education"
os.environ["QR_CHECKIN_DB_PATH"] = "/home/ubuntu/qr-checkin-data"

# Add the project root to the Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Now import the app
from src.main import app

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
